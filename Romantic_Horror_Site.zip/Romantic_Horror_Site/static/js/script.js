document.addEventListener('DOMContentLoaded', () => {
    const romanticScreen = document.getElementById('romantic-screen');
    const horrorScreen = document.getElementById('horror-screen');
    const finalScreen = document.getElementById('final-screen');
    const nameInput = document.getElementById('name-input');
    const submitBtn = document.getElementById('submit-btn');
    const progress = document.getElementById('progress');
    const glitchLayer = document.getElementById('glitch-layer');
    const arabicRain = document.getElementById('arabic-rain');
    const screamerFlash = document.getElementById('screamer-flash');
    const screamerImg = document.getElementById('screamer-img');
    const screamerTextOverlay = document.getElementById('screamer-text-overlay');
    const copyBtn = document.getElementById('copy-btn');
    const giftCommand = document.getElementById('gift-command');
    const ambientAudio = document.getElementById('ambient-audio');
    const screamAudio = document.getElementById('scream-audio');

    // User's screamers
    const screamerImages = [
        '/static/images/screamer1.jpg',
        '/static/images/screamer2.jpg'
    ];

    // Scary texts that appear with screamers
    const scaryTexts = [
        'БЫЛ ВЗЛОМАН ТЕЛЕФОН',
        'ТЫ УМРЁШЬ',
        'НЕ УХОДИ',
        'Я ВИЖУ ТЕБЯ',
        'ДАННЫЕ УДАЛЯЮТСЯ',
        'ГДЕ ТЫ?',
        'πού είσαι',
        'أنت ميت',
        'САМОУНИЧТОЖЕНИЕ',
        'СМОТРИ НА МЕНЯ',
        'НЕТ ВЫХОДА',
        'Я РЯДОМ'
    ];

    const arabicChars = 'أبتثجحخدذرزسشصضطظعغفقكلمنهويءآأؤإئ٠١٢٣٤٥٦٧٨٩';
    const matrixChars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789@#$%&*░▒▓█';
    const allChars = arabicChars + matrixChars;
    const scaryPhrases = ['أنت ميت', 'لا مخرج', 'أنا هنا', 'انظر خلفي', 'تم الاختراق', 'يراك الآن', 'جهازك ميت'];

    let rainInterval = null;
    let glitchInterval = null;
    let phraseInterval = null;
    let screamerInterval = null;
    let screamerIndex = 0;

    function createHearts(containerId, count = 15) {
        const container = document.getElementById(containerId);
        if (!container) return;
        for (let i = 0; i < count; i++) {
            const heart = document.createElement('div');
            heart.className = 'heart';
            heart.textContent = ['❤️', '💕', '💗', '💖'][Math.floor(Math.random() * 4)];
            heart.style.left = Math.random() * 100 + '%';
            heart.style.animationDuration = (4 + Math.random() * 5) + 's';
            heart.style.animationDelay = (Math.random() * 4) + 's';
            heart.style.fontSize = (14 + Math.random() * 18) + 'px';
            container.appendChild(heart);
        }
    }

    createHearts('hearts', 18);

    function startHorror() {
        romanticScreen.classList.remove('active');
        horrorScreen.classList.add('active');

        // Play audio from user's video
        try {
            ambientAudio.volume = 0.7;
            ambientAudio.currentTime = 0;
            ambientAudio.play().catch(() => {});
        } catch (e) {}

        // Progress bar
        let pct = 0;
        const progressTimer = setInterval(() => {
            pct += Math.random() * 5 + 3;
            if (pct >= 100) {
                pct = 100;
                clearInterval(progressTimer);
                // After progress — start aggressive screamers
                setTimeout(startScreamerSpam, 400);
            }
            progress.style.width = pct + '%';
        }, 130);

        startArabicRain();
        startGlitches();
        startScaryPhrases();
    }

    function startArabicRain() {
        rainInterval = setInterval(() => {
            const span = document.createElement('span');
            span.className = 'arabic-char';
            if (Math.random() < 0.35) span.classList.add('red');

            if (Math.random() < 0.1) {
                span.textContent = scaryPhrases[Math.floor(Math.random() * scaryPhrases.length)];
                span.style.fontSize = (14 + Math.random() * 10) + 'px';
            } else {
                span.textContent = allChars[Math.floor(Math.random() * allChars.length)];
                span.style.fontSize = (13 + Math.random() * 18) + 'px';
            }
            span.style.left = Math.random() * 100 + '%';
            span.style.animationDuration = (1.4 + Math.random() * 2.5) + 's';
            span.style.opacity = 0.55 + Math.random() * 0.45;
            arabicRain.appendChild(span);
            setTimeout(() => span.remove(), 4000);
        }, 38);
    }

    function startGlitches() {
        glitchInterval = setInterval(() => {
            glitchLayer.classList.add('active');
            setTimeout(() => glitchLayer.classList.remove('active'), 90 + Math.random() * 140);
        }, 250 + Math.random() * 400);
    }

    function startScaryPhrases() {
        phraseInterval = setInterval(() => {
            const div = document.createElement('div');
            div.className = 'arabic-char red';
            div.textContent = scaryPhrases[Math.floor(Math.random() * scaryPhrases.length)];
            div.style.left = (5 + Math.random() * 80) + '%';
            div.style.fontSize = (18 + Math.random() * 16) + 'px';
            div.style.animationDuration = (2.2 + Math.random() * 2) + 's';
            div.style.fontWeight = 'bold';
            arabicRain.appendChild(div);
            setTimeout(() => div.remove(), 4500);
        }, 1500);
    }

    // Flash screamers every second
    function startScreamerSpam() {
        screamerFlash.classList.add('active');

        // First flash immediately
        showNextScreamer();

        // Then every 1 second
        screamerInterval = setInterval(() => {
            showNextScreamer();
        }, 1000);

        // After ~12 seconds go to final
        setTimeout(() => {
            endHorror();
        }, 12000);
    }

    function showNextScreamer() {
        // Alternate between two images
        screamerImg.src = screamerImages[screamerIndex % 2];
        screamerIndex++;

        // Random scary text
        const text = scaryTexts[Math.floor(Math.random() * scaryTexts.length)];
        screamerTextOverlay.textContent = text;

        // Quick volume boost on scream
        try {
            screamAudio.volume = 0.75;
            screamAudio.currentTime = Math.random() * 8;
            screamAudio.play().catch(() => {});
        } catch (e) {}
    }

    function stopEffects() {
        if (rainInterval) clearInterval(rainInterval);
        if (glitchInterval) clearInterval(glitchInterval);
        if (phraseInterval) clearInterval(phraseInterval);
        if (screamerInterval) clearInterval(screamerInterval);
        try {
            ambientAudio.pause();
            screamAudio.pause();
        } catch (e) {}
    }

    function endHorror() {
        stopEffects();
        screamerFlash.classList.remove('active');
        horrorScreen.classList.remove('active');
        finalScreen.classList.add('active');
        createHearts('hearts-final', 12);
    }

    function handleSubmit() {
        const val = nameInput.value.trim();
        if (val.length === 0) {
            nameInput.style.borderColor = '#ff4d6d';
            nameInput.placeholder = 'Напиши хоть что-нибудь...';
            nameInput.focus();
            return;
        }
        startHorror();
    }

    submitBtn.addEventListener('click', handleSubmit);
    nameInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') handleSubmit();
    });

    copyBtn.addEventListener('click', async () => {
        const text = giftCommand.textContent;
        try {
            await navigator.clipboard.writeText(text);
            copyBtn.textContent = '✅ Скопировано!';
            copyBtn.classList.add('copied');
            setTimeout(() => {
                copyBtn.textContent = '📋 Копировать';
                copyBtn.classList.remove('copied');
            }, 2000);
        } catch (err) {
            const range = document.createRange();
            range.selectNode(giftCommand);
            window.getSelection().removeAllRanges();
            window.getSelection().addRange(range);
            try {
                document.execCommand('copy');
                copyBtn.textContent = '✅ Скопировано!';
                copyBtn.classList.add('copied');
            } catch (e) {
                copyBtn.textContent = 'Выдели и скопируй';
            }
            setTimeout(() => {
                copyBtn.textContent = '📋 Копировать';
                copyBtn.classList.remove('copied');
            }, 2000);
        }
    });
});
